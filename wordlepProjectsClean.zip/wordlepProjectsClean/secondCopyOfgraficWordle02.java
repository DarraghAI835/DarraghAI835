import java.awt.Color;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingUtilities;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import static javax.swing.SwingConstants.CENTER;
//import net.miginfocom.swing.MigLayout;

import java.util.Scanner;
import java.util.Random;
import java.util.HashMap;
import java.util.Scanner;
import java.awt.Font;
import java.awt.Color;
import java.awt.Panel;
import java.awt.Point;
import java.awt.Cursor;
import java.awt.Button;
import java.awt.Canvas;
import java.awt.TextField;
import java.awt.Graphics2D;
import java.awt.BasicStroke;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferStrategy;
import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.*;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.*;
import java.io.*;
import javax.swing.*;
import javax.swing.GroupLayout.Alignment;

public class secondCopyOfgraficWordle02 {
            
    private static final int WIN_WIDTH = 1000;
    private static final int WIN_HEIGHT = 750;
    private static Window window;   
    public static void main(String[] args) {
        
        window = new Window(WIN_WIDTH, WIN_HEIGHT, "Graphic Wordle");

        // ~60 FPS game loop
        // Using a separate Thread to display the window object on the screen
        // for simple games or animations like this one, just using
        }
    }
class Window { 
    Dictionaryg mydictionary = new Dictionaryg("wordlewords.txt");
    Dictionaryg mydictionary2d1 = new Dictionaryg("MyWordleWords.txt");
    
    int zero = 0;
    int one = 0;
    int two = 0;
    int three = 0;
    int four = 0;
    int Nguess = 0;
    int testVar =0;
    String nmn="Try Crane";
    int x = (int)(Math.random()*mydictionary.getSize());
    String theWord=mydictionary.getWord(x);
    //String theWord="lssll";
    String theGuess ="";
    //theWord = theWord.replace( "\n"," ");
    
    
    
    
    // Main Components of the window
    JFrame windowFrame;
    Panel rightPanel, bottomPanel,gridUpdates ;
    // Inner components that are used in this window
    JLabel info,info4;
    // JLabel bottomText,bottomText2;
    TextField tfTarget, tfResult;
    Button btnShoot, btnPlayAgain,button;
    Font font;
    // the football field
    //Field field;
    
    String feedback="Try Crane";
    Panel[][] pan = new Panel[5][6];
    JLabel[][] panText = new JLabel[5][6];   
    Window(int width, int height, String title) {        
        windowFrame = new JFrame();
        windowFrame.setBounds(0, 0, width, height);
        windowFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        windowFrame.setCursor(new Cursor(Cursor.HAND_CURSOR));
        windowFrame.setTitle(title);
        windowFrame.setResizable(true);
        windowFrame.setLayout(null);

        createRightPanel();
        for (int i=0; i<5;i++){
            for (int j=0; j<6;j++){
                createBottomPanel(400+(i*105),0+(j*105),100,100, i, j);
            }
        }
        windowFrame.add(rightPanel);
        windowFrame.setVisible(true);
    }
    
    
    private JLabel info3 = new JLabel("Ajouter");
    private void createRightPanel() {
        
        //lettersINword[] 
        rightPanel = new Panel();
        rightPanel.setBackground(Color.WHITE);
        rightPanel.setBounds(0, 0, 400,600);
        rightPanel.setLayout(null);
        
        final String formattedHTMLString = "<html>WORDLE<br> "
                                + "Green the letter is in the right place,<br>"
                                + "Gold the letter is in the word,<br>"
                                + "Gray the letter is not in the word.</html>";
        
        info = new JLabel(formattedHTMLString);
        info.setBounds(50, 50, 300, 150);
        info.setFont(new Font("SansSerif", Font.BOLD, 16));
        info.setFocusable(false);
        info.setForeground(Color.BLACK);
        
        final String hformattedHTMLString = "<html>"+feedback+ "</html>";
        
        //info3 = new JLabel(hformattedHTMLString);
        info3 = new JLabel(nmn);
        info3.setBounds(50, 500, 300, 150);
        info3.setFont(new Font("SansSerif", Font.BOLD, 25));
        info3.setFocusable(false);
        info3.setForeground(Color.BLACK);
        
        tfTarget = new TextField();
        tfTarget.setBounds(10, 200, 175, 80);
        tfTarget.setFont(new Font("SansSerif", Font.BOLD, 24));
        tfTarget.setFocusable(true);
        tfTarget.setForeground(Color.GREEN);
        
        btnShoot = new Button("Guess");
        btnShoot.setBounds(10, 310, 175, 80);
        //btnShoot.setBackground(Color.GREEN);
        btnShoot.setFocusable(true);
        //button.setOpaque(false);
        //btnShoot.setContentAreaFilled(false);
        //btnShoot.setBorderPainted(false);
        btnShoot.setFont(new Font("SansSerif", Font.BOLD, 24));
        btnShoot.addActionListener(new ActionListener() {
            // when the button is clicked, this method runs
            @Override
            public void actionPerformed(ActionEvent e) {
                int[] lettersINword = new int[5]; 
                int[] pdone= new int[5]; 
                    for(int i=0;i<5;i++){
        
                        
                            lettersINword[i]=1;
                           pdone[i]=1;
                    //System.out.print(lettersINword[i]);
                }
                
                //corner = tfTarget.getText();
                theGuess = (tfTarget.getText()).toLowerCase();
            
                System.out.println(theWord);
                 if (theGuess.length()!=5 && Nguess<6){
                     info3.setText("") ;
                     testVar=1;
                     info3.setText("To Long/Short"+testVar) ;
                }else if(Nguess<6){
                    Boolean isword =false;
                    // if ("lilss".equals(theGuess)||"lssll".equals(theGuess)||"sssll".equals(theGuess)||"12345".equals(theGuess)||"02354".equals(theGuess)){
                        // isword=true;
                    // }
                    for(int hh=0;hh<mydictionary2d1.getSize();hh++){
                        //System.out.print("mmmm");
                        if(mydictionary2d1.getWord(hh).equals(theGuess)){
                            System.out.print("mmmm");
                            isword=true;
                        }
                    }
                    //you ARE A STUDIP BASTARD Error should be in the following code
                    for(int hh=0;hh<mydictionary.getSize();hh++){
                        //System.out.print("kkkk");
                        if(mydictionary.getWord(hh).equals(theGuess)){
                            System.out.print("kkkk");
                            isword=true;
                        }
                    }
                    
                    for(int lh=0;lh<mydictionary2d1.getSize();lh++){
                        //System.out.print("kkkk");
                        if(mydictionary2d1.getWord(lh).equals(theGuess)){
                            System.out.print("mmmm");
                            isword=true;
                        }
                    }
                    if (isword==false){
                        //feedback="not a word";   
                        info3.setText("") ;
                        testVar=2;
                        info3.setText("not a word") ;
                        System.out.print(44);
                        Nguess=Nguess-1;
                    }
                    else{
                        //testVar=3;
                        System.out.print(45);
                        info3.setText("") ;
                        info3.setText("Try Crane") ;
                        for (int i=0; i <5;i++ ){
                            System.out.print(46);
                            
                            if (theGuess.charAt(i) ==theWord.charAt(i)){
                                System.out.print(48);
                                
                                    createUpdate_1(i,Nguess, String.valueOf(theGuess.charAt(i)),0);
                                    //System.out.print("{"+theGuess.charAt(i)+"}");
                                    lettersINword[i]=0;
                                    System.out.println(theGuess.charAt(i));
                                
                                pdone[i]=0;
                            }
                        }
                                    
                        for (int i=0; i <5;i++ ){
                            System.out.print(46);
                            for (int j=0; j <5;j++ ){
                                System.out.print(47);
                                    if (theGuess.charAt(i) ==theWord.charAt(j) && theGuess.charAt(i) !=theWord.charAt(i) && lettersINword[j]>0){
                                        createUpdate_1(i,Nguess, String.valueOf(theGuess.charAt(i)),1);
                                        //System.out.print("["+theGuess.charAt(i)+"]");
                                        
                                        // for (int k=0; k<=j;k++ ){
                                            
                                            // if (theGuess.charAt(i) ==theWord.charAt(i)){
                                            
                                            // }
                                            
                                            
                                                lettersINword[j]=0;  
                                            
                                            System.out.print(146);
                                            //lettersINword[i];
                                        //}
                                        j=5;
                                        pdone[i]=0;
                                        
                                    }
                                     // else //if (theGuess.charAt(i) !=theWord.charAt(j)){
                                     // {if (theGuess.charAt(i) ==theWord.charAt(i) && lettersINword[j]>0 ){
                                         // createUpdate_1(i,Nguess, String.valueOf(theGuess.charAt(i)),2);
                                         // //System.out.print("("+theGuess.charAt(i)+")");
                                     // }
                                 // }
                                
                            }
                        }
                        
                        for (int i=0; i <5;i++ ){
                            if (pdone[i]==1){
                                createUpdate_1(i,Nguess, String.valueOf(theGuess.charAt(i)),2);
                            }
                            } 
                            //System.out.println("pl"+lettersINword[i]);
                        }
                        Nguess=Nguess+1;
                    }
                    if (theGuess.equals(theWord)){
                       // info3.setText("") ;
                        info3.setText("You Win"+testVar) ; 
                        Nguess =6;
                    }else if(Nguess >5){
                        info3.setText("") ;
                        info3.setText("Try again tomorrow") ;
                    }
                
            
                // if (theGuess.equals(theWord)){
                    // info3.setText("") ;
                    // info3.setText("You Win") ; 
                    // Nguess =6;
                // }else if(Nguess >5){
                    // info3.setText("") ;
                    // info3.setText("Try again tomorrow") ;
                // }
                
                //System.out.print(Integer.valueOf(tfTarget.getText())+1);
                //createUpdate_1(1, Integer.valueOf(tfTarget.getText()));
            }
        });
        
        // creates the panel and adds all the above inner components
        rightPanel.add(info);
        rightPanel.add(info3);
        rightPanel.add(btnShoot);
        rightPanel.add(tfTarget);

        info.setVisible(true);
        tfTarget.setVisible(true);
        
        btnShoot.setVisible(true); 
        
       
        rightPanel.setVisible(true);
    }
    
    private void createBottomPanel(int x1, int y1, int z1, int w1 , int i, int j) {
        Panel bottomPanel = new Panel();
        // JLabel bottomText = new JLabel("ff");
        bottomPanel.setBounds(x1, y1, z1, w1);
        // bottomText.setFont(new Font("SansSerif", Font.BOLD, 18));
        // bottomText.setHorizontalAlignment(SwingConstants.CENTER);
        // bottomText.setVerticalAlignment(SwingConstants.CENTER);
        bottomPanel.setBackground(Color.GRAY);
        // bottomText.setForeground(Color.BLACK);
        bottomPanel.setLayout(null);
        //bottomText.setLayout(null);
        
        final String formattedHTMLString = "<html>"+" "+"<html> ";
                                
        
        JLabel bottomText2 = new JLabel(formattedHTMLString);
        bottomText2.setBounds(20, 20, 50, 50);
        bottomText2.setFont(new Font("SansSerif", Font.BOLD, 50));
        bottomText2.setFocusable(false);
        bottomText2.setForeground(Color.BLACK);
        bottomPanel.add(bottomText2);
        
        
        
        panText[i][j]=bottomText2;
        //panText[i][j].setText("kik");
        //System.out.println("hivb"+panText[i][j]);
        pan[i][j] = bottomPanel;
        
        //panText[i][j]=bottomText;
        //bottomText.setFont(new Font("SansSerif", Font.BOLD, 18));
        
        final String gformattedHTMLString = "<html> H </html>";
        
        info = new JLabel(gformattedHTMLString);
        
        //info.setFont(new Font("SansSerif", Font.BOLD, 16));
        //info.setFocusable(true);
        
        
        bottomPanel.add(info);
        bottomPanel.add(bottomText2);
        //panText[i][j]=info;
        windowFrame.add(bottomPanel);
        //windowFrame.add(bottomText);
        bottomPanel.setVisible(true);
        bottomText2.setVisible(true);
    }
    private void createUpdate_1(int i, int j, String k, int l) {
       /**gridUpdates = new Panel();
        gridUpdates.setBounds(400+(i*105),0+(j*105),100,100);
        gridUpdates.setBackground(Color.GREEN);
        gridUpdates.setLayout(null);
        windowFrame.add(gridUpdates);
        gridUpdates.setVisible(true);**/
        //Panel p = new Panel();
        if(l==0){
            pan[i][j].setBackground(Color.GREEN);    
        }else if (l==1){
            pan[i][j].setBackground(Color.YELLOW);
        }else{
            pan[i][j].setBackground(Color.GRAY);
        }
        //pan[i][j].setBackground(Color.GREEN);
        final String formattedHTMLString = "<html>"+k+"<html> ";
        JLabel bottomText2 = panText[i][j];
        bottomText2.setText(formattedHTMLString);
        //bottomText2 = new JLabel(formattedHTMLString);
        //bottomText2.setBounds(20, 20, 50, 50);
        bottomText2.setFont(new Font("SansSerif", Font.BOLD, 50));
        //bottomText2.setFocusable(false);
        bottomText2.setForeground(Color.BLACK);
        }
        //bottomPanel.add(bottomText2);
        
        //pan[i][j].add(bottomText2);
        //panText[i][j]=new JLabel("");//.setText("kik");
       // System.out.print(j);
        //JLabel l = new JLabel("h");
        //panText[i][j]=l;
        //panText[i][j].setFont(new Font("SansSerif", Font.BOLD, 16));
        //l.setFont(new Font("SansSerif", Font.BOLD, 16));
        //l.setForeground(Color.BLACK);
        // p.setBackground(Color.RED);
        // p.setBounds(700 , 100 , 500, 500);
        // panText[i][j].setText("kikhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh");
        // p.add(panText[i][j]);
        // pan[i][j].add(panText[i][j]);
        // windowFrame.add(pan[i][j]);
        // windowFrame.add(p);
        // pan[i][j].setVisible(true);
        // panText[i][j].setVisible(true);
    
}// most of the actual game play is handled here

class Dictionaryg{
     
    public String input[]; 

    public Dictionaryg(String c){
        input = load(c);
         
    }
    
    public int getSize(){
        return input.length;
    }
    
    public String getWord(int n){
        return input[n];
    }
    
    private String[] load(String file) {
        File aFile = new File(file);     
        StringBuffer contents = new StringBuffer();
        BufferedReader input = null;
        try {
            input = new BufferedReader( new FileReader(aFile) );
            String line = null; 
            int i = 0;
            while (( line = input.readLine()) != null){
                contents.append(line);
                i++;
                contents.append(System.getProperty("line.separator"));
            }
        }catch (FileNotFoundException ex){
            System.out.println("Can't find the file - are you sure the file is in this location: "+file);
            ex.printStackTrace();
        }catch (IOException ex){
            System.out.println("Input output exception while processing file");
            ex.printStackTrace();
        }finally{
            try {
                if (input!= null) {
                    input.close();
                }
            }catch (IOException ex){
                System.out.println("Input output exception while processing file");
                ex.printStackTrace();
            }
        }
        String[] array = contents.toString().split("\n");
        for (int i=0; i<2315;i++){
            array[i] = array[i].strip();
        }
        //array = array.strip();
        for(String s: array){
            s.trim();
            s.strip();
        }
        return array;
    }
}

