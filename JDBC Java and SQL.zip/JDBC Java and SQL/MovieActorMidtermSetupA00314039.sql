DROP DATABASE IF EXISTS MovieActorMidterm;
CREATE DATABASE IF NOT EXISTS MovieActorMidterm;
USE MovieActorMidterm;

DROP TABLE IF EXISTS Movies;


CREATE TABLE Movies (
	Movie_id DECIMAL(2) NOT NULL PRIMARY KEY,
	Movie_Name VARCHAR(30),
    Director_id DECIMAL(2) NOT NULL,
    Budget decimal(20) NOT NULL,
    Actor_id DECIMAL(2) NOT NULL,
    Actress_id DECIMAL(2) NOT NULL,
    Supporting_id DECIMAL(2) NOT NULL,
    Company VARCHAR(20) NOT NULL,
    Franchise VARCHAR(20)
	);
ALTER TABLE Movies ADD COLUMN Earnings DECIMAL(20);
CREATE TABLE People(
	Person_id int auto_increment,
    First_Name VARCHAR(20) NOT NULL,
    Last_Name VARCHAR(20) NOT NULL,
    Age DECIMAL(2) NOT NULL,
    Country VARCHAR(20) NOT NULL,
    PRIMARY KEY (Person_id)
);
CREATE TABLE movielog (
	M_id INT,
    action_type     VARCHAR(50),
	action_date     DATETIME
    
);
DROP TRIGGER IF EXISTS trMoviesI;
DELIMITER //
CREATE  TRIGGER trMoviesI
	AFTER INSERT on MOVIES
	FOR EACH ROW
	BEGIN
	INSERT INTO movielog  VALUES (NEW.Movie_id, 'INSERTED', NOW());
END//
DROP TRIGGER IF EXISTS trMoviesD;
DELIMITER //
CREATE  TRIGGER trMoviesD
	AFTER DELETE on MOVIES
	FOR EACH ROW
	BEGIN
	INSERT INTO movielog  VALUES (OLD.Movie_id, 'DELETED', NOW());
END//

SELECT 'INSERTING DATA INTO DATABASE' as 'INFO';

-- INSERT INTO People VALUES(1,'John','Doe',54,'Irish');
-- INSERT INTO People VALUES(2,'Jane','Doe',53,'Irish');
-- INSERT INTO People VALUES(3,'John','Wane',44,'American');
-- INSERT INTO People VALUES(4,'Daniel','Radcliff',32,'British');
-- INSERT INTO People VALUES(5,'Mary','Murphy',44,'Australian');
-- INSERT INTO People VALUES(6,'Jane','Holland',43,'Swiss');
-- INSERT INTO People VALUES(7,'Sponge','Bob',23,'Bikini Bottom');
-- INSERT INTO People VALUES(8,'Christoper','Nolan', 54, 'American');
-- INSERT INTO People VALUES(9,'Stanley','Kubrick',68,'American');
-- INSERT INTO People VALUES(10,'Steven','Speilberg',77,'American');
-- INSERT INTO People VALUES(11,'Liam','Neeson',75,'Irish');
-- INSERT INTO People VALUES(12,'Saoirse','Ronan',33,'Irish');


-- INSERT INTO MOVIES VALUES(1,'The Longest Mile',2,100000,1,2,4,'Strand Cinema','Length Franchise', 124200);
-- INSERT INTO MOVIES VALUES(2,'Dawn of Databases',9,1001,7,12,4,'Yellow House','Ashley Saga', 1000053);
-- INSERT INTO MOVIES VALUES(3,'SQL Struggle',10,1002,7,12,5,'Yellow House','Ashley Saga', 9999999);
-- INSERT INTO MOVIES VALUES(4,'Darragh Gets an A',8,1003,11,5,3,'Yellow House','Ashley Saga', 432590823);
-- INSERT INTO MOVIES VALUES(5,'The Hungry Catapillar',6,100,8,2,4,'Westmeath Cinema','Catapillar', 1242);
-- INSERT INTO MOVIES VALUES(6,'The VERY Hungry Catapillar',6,1000,4,5,10,'Moate Productions','Catapillar', 10);
-- INSERT INTO MOVIES VALUES(7,'Harry Potter',8,10087650,7,2,6,'Universal','Harry Potter', 124254300);
-- INSERT INTO MOVIES VALUES(8,'Harry Potter Back in the Habit',2,1540000,1,3,6,'Universal','Harry Potter', 88500);
-- INSERT INTO MOVIES VALUES(9,'Harry Potter and the SQL Resit',9,107000,3,12,4,'Universal','Harry Potter', 674200);
-- INSERT INTO MOVIES VALUES(10,'Chain Saw Man',2,100,1,3,4,'Moate Cinema','Chainsaw', 1200);
-- INSERT INTO MOVIES VALUES(11,'Chain Saw Boy',2,100000,1,3,4,'Moate Cinema','Chainsaw', 1200);

DROP PROCEDURE IF EXISTS spUpdatePerson
DELIMITER //
CREATE PROCEDURE spUpdatePerson 
	(
		thePerson_id int,
		NEW_First_Name VARCHAR(20),
		NEW_Last_Name VARCHAR(20),
		NEW_Age DECIMAL(2),
		NEW_Country VARCHAR(20)
	)
	BEGIN
	DECLARE sql_error TINYINT DEFAULT FALSE;
	DECLARE CONTINUE HANDLER FOR SQLEXCEPTION 
	SET sql_error = TRUE;
	START TRANSACTION; 
		#UPDATE PEOPLE SET First_Name="TOP" WHERE Person_id = 1;
		UPDATE People SET First_Name=New_First_Name, Last_Name=New_Last_Name, Age= NEW_Age,Country=NEW_Country WHERE Person_id=thePerson_id;   
		IF sql_error = FALSE THEN 
			COMMIT;      
		ELSE 
			ROLLBACK;
		END IF;
END//
DROP FUNCTION IF EXISTS fnMovieProfit;
DELIMITER //
 CREATE FUNCTION fnMovieProfit
 (
 varMovie_id INT
 )
 RETURNS DECIMAL(10)
 DETERMINISTIC
 BEGIN
 DECLARE profit DECIMAL(10);
 SELECT (Earnings-Budget) INTO profit FROM Movies WHERE Movie_id=varMovie_id LIMIT 1;
 RETURN profit;
END//

 DROP EVENT IF EXISTS evMovieLogReset;
 DELIMITER //
 CREATE EVENT evMovieLogReset
 ON SCHEDULE EVERY 1 hour
 STARTS Now()
 DO BEGIN
	DELETE FROM MovieLog WHERE action_date<Now()- INTERVAL 1 HOUR;
END //


 
INSERT INTO People VALUES(1,'John','Doe',54,'Irish');
INSERT INTO People VALUES(2,'Jane','Doe',53,'Irish');
INSERT INTO People VALUES(3,'John','Wane',44,'American');
INSERT INTO People VALUES(4,'Daniel','Radcliff',32,'British');
INSERT INTO People VALUES(5,'Mary','Murphy',44,'Australian');
INSERT INTO People VALUES(6,'Jane','Holland',43,'Swiss');
INSERT INTO People VALUES(7,'Sponge','Bob',23,'Bikini Bottom');
INSERT INTO People VALUES(8,'Christoper','Nolan', 54, 'American');
INSERT INTO People VALUES(9,'Stanley','Kubrick',68,'American');
INSERT INTO People VALUES(10,'Steven','Speilberg',77,'American');
INSERT INTO People VALUES(11,'Liam','Neeson',75,'Irish');
INSERT INTO People VALUES(12,'Saoirse','Ronan',33,'Irish');


INSERT INTO MOVIES VALUES(1,'The Longest Mile',2,100000,1,2,4,'Strand Cinema','Length Franchise', 124200);
INSERT INTO MOVIES VALUES(2,'Dawn of Databases',9,1001,7,12,4,'Yellow House','Ashley Saga', 1000053);
INSERT INTO MOVIES VALUES(3,'SQL Struggle',10,1002,7,12,5,'Yellow House','Ashley Saga', 9999999);
INSERT INTO MOVIES VALUES(4,'Darragh Gets an A',8,1003,11,5,3,'Yellow House','Ashley Saga', 432590823);
INSERT INTO MOVIES VALUES(5,'The Hungry Catapillar',6,100,8,2,4,'Westmeath Cinema','Catapillar', 1242);
INSERT INTO MOVIES VALUES(6,'The VERY Hungry Catapillar',6,1000,4,5,10,'Moate Productions','Catapillar', 10);
INSERT INTO MOVIES VALUES(7,'Harry Potter',8,10087650,7,2,6,'Universal','Harry Potter', 124254300);
INSERT INTO MOVIES VALUES(8,'Harry Potter Back in the Habit',2,1540000,1,3,6,'Universal','Harry Potter', 88500);
INSERT INTO MOVIES VALUES(9,'Harry Potter and the SQL Resit',9,107000,3,12,4,'Universal','Harry Potter', 674200);
INSERT INTO MOVIES VALUES(10,'Chain Saw Man',2,100,1,3,4,'Moate Cinema','Chainsaw', 1200);
INSERT INTO MOVIES VALUES(11,'Chain Saw Boy',2,100000,1,3,4,'Moate Cinema','Chainsaw', 1200);
SELECT * FROM People;
SELECT * FROM Movies;
SELECT * FROM movielog;
DESC Movies;
show tables;
SELECT fnMovieProfit(1);
SELECT fnMovieProfit('1');
-- CALL spUpdatePerson(1, 'Darragh', 'Counihan',23,'Irish');