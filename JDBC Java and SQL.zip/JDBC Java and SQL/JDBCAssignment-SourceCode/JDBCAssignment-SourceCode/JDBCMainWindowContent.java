import java.awt.*;
import java.awt.event.*;
import java.io.FileWriter;
import java.io.PrintWriter;
import javax.swing.*;
import javax.swing.border.*;
import java.sql.*;


@SuppressWarnings("serial")
public class JDBCMainWindowContent extends JInternalFrame implements ActionListener
{	
	String cmd = null;
	String[] record;

	// DB Connectivity Attributes
	private Connection con = null;
	private Statement stmt = null;
	private ResultSet rs = null;

	private Container content;

	private JPanel detailsPanel;
	private JPanel detailsPersonPanel;
	private JPanel exportButtonPanel;
	
	//private JPanel exportConceptDataPanel;
	private JScrollPane dbContentsPanel;
	private JScrollPane dbContentsPanelPeople;

	private Border lineBorder;

	private JLabel MovieIDLabel=new JLabel("ID:                 ");
	private JLabel MovieNameLabel=new JLabel("Movie Name:               ");
	private JLabel DirectorIDLabel=new JLabel("DirectorID:      ");
	private JLabel BudgetLabel=new JLabel("Budget:        ");
	private JLabel LeadActorIDLabel=new JLabel("Lead Actor:                 ");
	private JLabel LeadActressIDLabel=new JLabel("Lead Actress:               ");
	private JLabel SupportingIDLabel=new JLabel("Supporting:      ");
	private JLabel CompanyLabel=new JLabel("Company:      ");
	private JLabel FranchiseLabel=new JLabel("Franchise:        ");
	private JLabel EarningsLabel=new JLabel("Earnings:        ");
	
	private JLabel PersonIDLabel=new JLabel("Person Id:                 ");
	private JLabel FirstNameLabel=new JLabel("First Name:               ");
	private JLabel LastNameLabel=new JLabel("Last Name:      ");
	private JLabel AgeLabel=new JLabel("Age:        ");
	private JLabel CountryLabel=new JLabel("Nationality:                 ");

	private JTextField MovieIDTF= new JTextField(10);
	private JTextField MovieNameTF=new JTextField(20);
	private JTextField DirectorIDTF=new JTextField(10);
	private JTextField BudgetTF=new JTextField(20);
	private JTextField LeadActorIDTF=new JTextField(10);
	private JTextField LeadActressIDTF=new JTextField(10);
	private JTextField SupportingIDTF=new JTextField(10);
	private JTextField CompanyTF=new JTextField(20);
	private JTextField FranchiseTF=new JTextField(20);
	private JTextField EarningsTF=new JTextField(20);
	
	private JTextField PersonIDTF=new JTextField(10);
	private JTextField FirstNameTF=new JTextField(20);
	private JTextField LastNameTF=new JTextField(20);
	private JTextField AgeTF=new JTextField(10);
	private JTextField CountryTF=new JTextField(20);


	private static QueryTableModel TableModel = new QueryTableModel();
	private static QueryTableModel peopleTableModel = new QueryTableModel();
	//Add the models to JTabels
	private JTable TableofDBContents=new JTable(TableModel);
	private JTable TableofPeopleDBContents = new JTable(peopleTableModel);
	//Buttons for inserting, and updating members
	//also a clear button to clear details panel
	private JButton updateMovieButton = new JButton("Update Movie");
	private JButton insertMovieButton = new JButton("Insert Movie");
	private JButton exportMovieButton  = new JButton("Export Movie");
	private JButton deleteMovieButton  = new JButton("Delete Movie");
	private JButton clearMovieButton  = new JButton("Clear Movie");
	
	private JButton updatePersonButton = new JButton("Update Person");
	private JButton insertPersonButton = new JButton("Insert Person");
	private JButton exportPersonButton  = new JButton("Export Person");
	private JButton deletePersonButton  = new JButton("Delete Person");
	private JButton clearPersonButton  = new JButton("Clear Person");

	private JButton  numMoviesWithPerson = new JButton("NumMoviesWithPerson:");
	private JTextField numMoviesWithPersonTF  = new JTextField(12);
	private JButton movieProfitability  = new JButton("MovieProfitability");
	private JTextField movieProfitabilityTF  = new JTextField(12);
	private JButton	avgAgePerMovie  = new JButton("AvgAgePerMovie");
	private JButton NationalityInMovie  = new JButton("NationalitiesInMovie");
	



	public JDBCMainWindowContent( String aTitle)
	{	
		//setting up the GUI
		super(aTitle, false,false,false,false);
		setEnabled(true);

		initiate_db_conn();
		//add the 'main' panel to the Internal Frame
		content=getContentPane();
		content.setLayout(null);
		content.setBackground(Color.lightGray);
		lineBorder = BorderFactory.createEtchedBorder(15, Color.red, Color.black);

		//setup details panel and add the components to it
		detailsPanel=new JPanel();
		detailsPanel.setLayout(new GridLayout(10,2));
		detailsPanel.setBackground(Color.lightGray);
		detailsPanel.setBorder(BorderFactory.createTitledBorder(lineBorder, "Movie CRUD Actions"));

		detailsPanel.add(MovieIDLabel);			
		detailsPanel.add(MovieIDTF);
		detailsPanel.add(MovieNameLabel);		
		detailsPanel.add(MovieNameTF);
		detailsPanel.add(DirectorIDLabel);		
		detailsPanel.add(DirectorIDTF);
		detailsPanel.add(BudgetLabel);	
		detailsPanel.add(BudgetTF);
		detailsPanel.add(LeadActorIDLabel);		
		detailsPanel.add(LeadActorIDTF);
		detailsPanel.add(LeadActressIDLabel);
		detailsPanel.add(LeadActressIDTF);
		detailsPanel.add(SupportingIDLabel);
		detailsPanel.add(SupportingIDTF);
		detailsPanel.add(CompanyLabel);
		detailsPanel.add(CompanyTF);
		detailsPanel.add(FranchiseLabel);
		detailsPanel.add(FranchiseTF);
		detailsPanel.add(EarningsLabel);
		detailsPanel.add(EarningsTF);
		
		
		//Set up the person panel
		detailsPersonPanel=new JPanel();
		detailsPersonPanel.setLayout(new GridLayout(5,2));
		detailsPersonPanel.setBackground(Color.lightGray);
		detailsPersonPanel.setBorder(BorderFactory.createTitledBorder(lineBorder, "People CRUD Actions"));

		detailsPersonPanel.add(PersonIDLabel);			
		detailsPersonPanel.add(PersonIDTF);
		detailsPersonPanel.add(FirstNameLabel);		
		detailsPersonPanel.add(FirstNameTF);
		detailsPersonPanel.add(LastNameLabel);		
		detailsPersonPanel.add(LastNameTF);
		detailsPersonPanel.add(AgeLabel);	
		detailsPersonPanel.add(AgeTF);
		detailsPersonPanel.add(CountryLabel);		
		detailsPersonPanel.add(CountryTF);

		//setup details panel and add the components to it
		exportButtonPanel=new JPanel();
		exportButtonPanel.setLayout(new GridLayout(3,2));
		exportButtonPanel.setBackground(Color.lightGray);
		exportButtonPanel.setBorder(BorderFactory.createTitledBorder(lineBorder, "Export and Get Data"));
		exportButtonPanel.add(numMoviesWithPerson);
		exportButtonPanel.add(numMoviesWithPersonTF);
		exportButtonPanel.add(movieProfitability);
		exportButtonPanel.add(movieProfitabilityTF);
		exportButtonPanel.add(avgAgePerMovie);
		exportButtonPanel.add(NationalityInMovie);
		exportButtonPanel.setSize(450, 200);
		exportButtonPanel.setLocation(3, 300);
		content.add(exportButtonPanel);

		insertMovieButton.setSize(120, 30);
		insertMovieButton.setFont(new Font("Arial", Font.PLAIN, 12));
		updateMovieButton.setSize(120, 30);
		updateMovieButton.setFont(new Font("Arial", Font.PLAIN, 12));
		exportMovieButton.setSize (120, 30);
		exportMovieButton.setFont(new Font("Arial", Font.PLAIN, 12));
		deleteMovieButton.setSize (120, 30);
		deleteMovieButton.setFont(new Font("Arial", Font.PLAIN, 12));
		clearMovieButton.setSize (120, 30);
		clearMovieButton.setFont(new Font("Arial", Font.PLAIN, 12));
		
		insertMovieButton.setLocation(260, 10);
		updateMovieButton.setLocation(260, 110);
		exportMovieButton.setLocation (260, 160);
		deleteMovieButton.setLocation (260, 60);
		clearMovieButton.setLocation (260, 210);

		insertMovieButton.addActionListener(this);
		updateMovieButton.addActionListener(this);
		exportMovieButton.addActionListener(this);
		deleteMovieButton.addActionListener(this);
		clearMovieButton.addActionListener(this);

		insertPersonButton.setSize(120, 30);
		insertPersonButton.setFont(new Font("Arial", Font.PLAIN, 12));
		updatePersonButton.setSize(120, 30);
		updatePersonButton.setFont(new Font("Arial", Font.PLAIN, 12));
		exportPersonButton.setSize (120, 30);
		exportPersonButton.setFont(new Font("Arial", Font.PLAIN, 12));
		deletePersonButton.setSize (120, 30);
		deletePersonButton.setFont(new Font("Arial", Font.PLAIN, 12));
		clearPersonButton.setSize (120, 30);
		clearPersonButton.setFont(new Font("Arial", Font.PLAIN, 12));
		
		insertPersonButton.setLocation(600, 10);
		updatePersonButton.setLocation(600, 110);
		exportPersonButton.setLocation (600, 160);
		deletePersonButton.setLocation (600, 60);
		clearPersonButton.setLocation (600, 210);

		insertPersonButton.addActionListener(this);
		updatePersonButton.addActionListener(this);
		exportPersonButton.addActionListener(this);
		deletePersonButton.addActionListener(this);
		clearPersonButton.addActionListener(this);
		
		this.numMoviesWithPerson.addActionListener(this);
		this.movieProfitability.addActionListener(this);
		this.avgAgePerMovie.addActionListener(this);
		this.NationalityInMovie.addActionListener(this);

		content.add(insertMovieButton);
		content.add(updateMovieButton);
		content.add(exportMovieButton);
		content.add(deleteMovieButton);
		content.add(clearMovieButton);
		
		content.add(insertPersonButton);
		content.add(updatePersonButton);
		content.add(exportPersonButton);
		content.add(deletePersonButton);
		content.add(clearPersonButton);


		TableofDBContents.setPreferredScrollableViewportSize(new Dimension(500, 250));
		TableofPeopleDBContents.setPreferredScrollableViewportSize(new Dimension(900, 300));

		dbContentsPanel=new JScrollPane(TableofDBContents,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		dbContentsPanel.setBackground(Color.lightGray);
		dbContentsPanel.setBorder(BorderFactory.createTitledBorder(lineBorder,"Movie Database Content"));

		dbContentsPanelPeople=new JScrollPane(TableofPeopleDBContents,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		dbContentsPanelPeople.setBackground(Color.lightGray);
		dbContentsPanelPeople.setBorder(BorderFactory.createTitledBorder(lineBorder,"People Database Content"));
		
		detailsPanel.setSize(250, 300);
		detailsPanel.setLocation(3,0);
		detailsPersonPanel.setSize(210,150);
		detailsPersonPanel.setLocation(390,0);
		dbContentsPanel.setSize(670, 270);
		dbContentsPanel.setLocation(480, 240);
		dbContentsPanelPeople.setSize(420, 220);
		dbContentsPanelPeople.setLocation(730, 10);

		content.add(detailsPanel);
		content.add(detailsPersonPanel);
		content.add(dbContentsPanel);
		content.add(dbContentsPanelPeople);

		setSize(982,645);
		setVisible(true);

		TableModel.refreshFromDB(stmt,"M");
		peopleTableModel.refreshFromDB(stmt,"P");
	}

	public void initiate_db_conn()
	{
		try
		{
			// Load the JConnector Driver
			Class.forName("com.mysql.cj.jdbc.Driver");
			// Specify the DB Name
		
            String url="jdbc:mysql://localhost:3306/MovieActorMidterm";
			
			// Connect to DB using DB URL, Username and password
			con = DriverManager.getConnection(url, "root", "");
			
			//Create a generic statement which is passed to the TestInternalFrame1
			stmt = con.createStatement();
		}
		catch(Exception e)
		{
			System.out.println("Error: Failed to connect to database\n"+e.getMessage());
			System.out.print("Error: Failed to connect to database, stacktrace below\n");
			e.printStackTrace();
		}
	}

	//event handling 
	public void actionPerformed(ActionEvent e)
	{
		Object target=e.getSource();
		if (target == clearMovieButton)
		{
			MovieIDTF.setText("");
			MovieNameTF.setText("");
			DirectorIDTF.setText("");
			BudgetTF.setText("");
			LeadActorIDTF.setText("");
			LeadActressIDTF.setText("");
			SupportingIDTF.setText("");
			CompanyTF.setText("");
			FranchiseTF.setText("");
			EarningsTF.setText("");

		}
		if (target == clearPersonButton)
		{
			PersonIDTF.setText("");
			FirstNameTF.setText("");
			LastNameTF.setText("");
			AgeTF.setText("");
			CountryTF.setText("");
		}
		if (target == updateMovieButton)
		{
			try {
				String checkId ="SELECT Movie_id FROM Movies";
				ResultSet data = stmt.executeQuery(checkId);
				boolean IdInUse = false; 
				while(data.next())
				{	
					if (MovieIDTF.getText().equals(data.getString(1)) ) {
						IdInUse = true;
					}
					
				}
				if(MovieIDTF.getText().equals("")||MovieNameTF.getText().equals("")||DirectorIDTF.getText().equals("")||BudgetTF.getText().equals("")||LeadActorIDTF.getText().equals("")||LeadActressIDTF.getText().equals("")||SupportingIDTF.getText().equals("")||CompanyTF.getText().equals("")||FranchiseTF.getText().equals("")){
					new JDBCMainWindowPopUp("Please fill in all required feilds");
				}
				else if(IdInUse) {
					
					stmt.executeUpdate("UPDATE MOVIES SET Movie_Name='"+MovieNameTF.getText()+"',Director_id="+DirectorIDTF.getText()+",Budget="+BudgetTF.getText()+",Actor_id="+LeadActorIDTF.getText()+", Actress_id="+LeadActressIDTF.getText() +",Supporting_id="+SupportingIDTF.getText()+",Company='"+CompanyTF.getText()+"',Franchise='"+FranchiseTF.getText()+"' WHERE Movie_id LIKE '"+MovieIDTF.getText() +"'");
					//stmt.executeUpdate("UPDATE MOVIES SET Movie_Name='It work' WHERE Movie_id = '"+MovieIDTF.getText() +"'");
				}else {
					new JDBCMainWindowPopUp("This Movie ID does not exist in the Database");
				}
			}
			catch (SQLException sqle)
			{
				System.err.println("Error with  Update:\n"+sqle.toString());
				sqle.printStackTrace();
			}
			
			finally
			{ 
				System.out.println("line 320");
				TableModel.refreshFromDB(stmt,"M");
				//TableModel.checkID(stmt);
			}
		}
		if (target == updatePersonButton)
		{
			try {
				String checkId ="SELECT Person_id FROM People";
				ResultSet data = stmt.executeQuery(checkId);
				boolean IdInUse = false; 
				while(data.next())
				{	
					if (PersonIDTF.getText().equals(data.getString(1)) ) {
						IdInUse = true;
					}
					
				}
				if(PersonIDTF.getText().equals("")||FirstNameTF.getText().equals("")||LastNameTF.getText().equals("")||AgeTF.getText().equals("")||CountryTF.getText().equals("")){
					new JDBCMainWindowPopUp("Please fill in all required feilds");
				}
				else if(IdInUse) {
					
					//stmt.executeUpdate("UPDATE PEOPLE SET First_Name='"+FirstNameTF.getText()+"',Last_Name="+LastNameTF.getText()+",Age="+AgeTF.getText()+",Country="+CountryTF.getText()+" WHERE Person_id LIKE '"+PersonIDTF.getText() +"'");
					stmt.executeUpdate("CALL spUpdatePerson("+PersonIDTF.getText() +", '"+FirstNameTF.getText()+"', '"+LastNameTF.getText()+"',"+AgeTF.getText()+",'"+CountryTF.getText()+"');");
					
				}else {
					new JDBCMainWindowPopUp("This Person ID does not exist in the Database");
				}
			}
			catch (SQLException sqle)
			{
				System.err.println("Error with  Update:\n"+sqle.toString());
				sqle.printStackTrace();
			}
			
			finally
			{ 
				System.out.println("line 377");
				peopleTableModel.refreshFromDB(stmt,"P");
				//TableModel.checkID(stmt);
			}
		}
		if (target == deleteMovieButton)
		{
			try {
				String checkId ="SELECT Movie_id FROM Movies";
				ResultSet data = stmt.executeQuery(checkId);
				boolean IdInUse = false; 
				while(data.next())
				{	
					if (MovieIDTF.getText().equals(data.getString(1)) ) {
						IdInUse = true;
					}
					
				}
				if(IdInUse) {
					stmt.executeUpdate("DELETE FROM MOVIES WHERE movie_id LIKE '"+MovieIDTF.getText() +"'");
				}else {
					new JDBCMainWindowPopUp("This Movie ID does not exist in the Database");
				}
			}
			catch (SQLException sqle)
			{
				System.err.println("Error with  delete:\n"+sqle.toString());
				sqle.printStackTrace();
			}
			
			finally
			{ 
				System.out.println("line 320");
				TableModel.refreshFromDB(stmt,"M");
				//TableModel.checkID(stmt);
			}
		}
		if (target == deletePersonButton)
		{
			try {
				String checkId ="SELECT Person_id FROM People";
				ResultSet data = stmt.executeQuery(checkId);
				boolean IdInUse = false; 
				while(data.next())
				{	
					if (PersonIDTF.getText().equals(data.getString(1)) ) {
						IdInUse = true;
					}
					
				}
				if(IdInUse) {
					stmt.executeUpdate("DELETE FROM PEOPLE WHERE person_id LIKE '"+PersonIDTF.getText() +"'");
				}else {
					new JDBCMainWindowPopUp("This Person ID does not exist in the Database");
				}
			}
			catch (SQLException sqle)
			{
				System.err.println("Error with  delete:\n"+sqle.toString());
				sqle.printStackTrace();
			}
			
			finally
			{ 
				System.out.println("line 367");
				peopleTableModel.refreshFromDB(stmt,"P");
				//TableModel.checkID(stmt);
			}
		}
		if (target == insertMovieButton)
		{		 
			try
			{
				String checkId ="SELECT Movie_id FROM Movies";
				ResultSet data = stmt.executeQuery(checkId);
				System.out.print(data);
				boolean IdInUse = false; 
				while(data.next())
				{	
					System.out.print("this is new data line: ");
					System.out.print(MovieIDTF.getText());
					System.out.print(data.getString(1));
					System.out.println(IdInUse);
					
					if (MovieIDTF.getText().equals(data.getString(1)) ) {
						IdInUse = true;
						System.out.println(data.getString(1));
						System.out.print(IdInUse);	
					}
					
				}
				if (IdInUse==true) {
					new JDBCMainWindowPopUp("This Movie ID is in use");
				}else {
//					String updateTemp ="INSERT INTO Movies VALUES("+
//					 +",'"+MovieNameTF.getText()+"','"+DirectorIDTF.getText()+"',"+BudgetTF.getText()+",'"+LeadActorIDTF.getText()+"','"
//					+LeadActressIDTF.getText()+"','"+SupportingIDTF.getText()+"',"+CompanyTF.getText()+","+FranchiseTF.getText()+"','"+EarningsTF.getText()+");";
//							
					//String updateTemp ="INSERT INTO Movies VALUES("+
					//MovieIDTF.getText() +",'"+MovieNameTF.getText()+"','"+DirectorIDTF.getText()+"',"+BudgetTF.getText()+",'"+LeadActorIDTF.getText()+"','"
//					+LeadActressIDTF.getText()+"','"+SupportingIDTF.getText()+"',"+CompanyTF.getText()+"','"+FranchiseTF.getText()+"','"+EarningsTF.getText()+");";
//					System.out.println(updateTemp);
					String updateTemp = "INSERT INTO MOVIES VALUES("+MovieIDTF.getText() +",'"+MovieNameTF.getText() +"',"+DirectorIDTF.getText()+","+BudgetTF.getText()+","+LeadActorIDTF.getText()+","+LeadActressIDTF.getText()+","+SupportingIDTF.getText()+",'"+CompanyTF.getText()+"','"+FranchiseTF.getText()+"', "+EarningsTF.getText()+");";
					stmt.executeUpdate(updateTemp);
					//BigDecimal(String)
					
				}
				
				
				//String updateTemp ="INSERT INTO Movies VALUES("+
				//null +",'"+FirstNameTF.getText()+"','"+LastNameTF.getText()+"',"+AgeTF.getText()+",'"+GenderTF.getText()+"','"
				//+PositionTF.getText()+"','"+DepartmentTF.getText()+"',"+RateTF.getText()+","+HoursTF.getText()+");";

				//stmt.executeUpdate(updateTemp);

			}
			catch (SQLException sqle)
			{
				System.err.println("Error with  insert:\n"+sqle.toString());
				sqle.printStackTrace();
			}
			finally
			{
				System.out.println("line 317");
				TableModel.refreshFromDB(stmt,"M");
				//TableModel.checkID(stmt);
			}
		}
		//insertPersonButton
		if (target == insertPersonButton)
		{		 
			try
			{
				String checkId ="SELECT Person_id FROM People";
				ResultSet data = stmt.executeQuery(checkId);
				System.out.print(data);
				boolean IdInUse = false; 
				while(data.next())
				{	
					if (PersonIDTF.getText().equals(data.getString(1)) ) {
						IdInUse = true;
					}
					
				}
				if (IdInUse==true) {
					new JDBCMainWindowPopUp("This Persons ID is in use");
				}else {
					String updateTemp = "INSERT INTO People VALUES("+PersonIDTF.getText() +",'"+FirstNameTF.getText() +"','"+LastNameTF.getText()+"',"+AgeTF.getText()+",'"+CountryTF.getText()+"');";
					stmt.executeUpdate(updateTemp);
				}

			}
			catch (SQLException sqle)
			{
				System.err.println("Error with  insert:\n"+sqle.toString());
				sqle.printStackTrace();
			}
			finally
			{
				System.out.println("line 399");
				peopleTableModel.refreshFromDB(stmt,"P");
				//TableModel.checkID(stmt);
			}
		}
		if (target == exportMovieButton) {
			try {
				cmd = "select * from Movies";
				rs = stmt.executeQuery(cmd);
				writeToFile(rs,"M");
			}catch(SQLException sqle){
				System.out.println("Error with export:\n"+sqle.toString());
				sqle.printStackTrace();
			}
		}
		if (target == exportPersonButton) {
			try {
				cmd = "select * from People";
				rs = stmt.executeQuery(cmd);
				writeToFile(rs,"P");
			}catch(SQLException sqle){
				System.out.println("Error with export:\n"+sqle.toString());
				sqle.printStackTrace();
			}
		}
		
		if(target == numMoviesWithPerson) {
			try {
				
				//PreparedStatement ps=con.prepareStatement("SELECT Count(Movie_Name) FROM MOVIES WHERE Director_id = 1");
				PreparedStatement ps=con.prepareStatement("SELECT Count(Movie_Name) FROM MOVIES WHERE Director_id = ? or Actor_id = ? or Actress_id = ? or Supporting_id = ? ");
				ps.setString(1, numMoviesWithPersonTF.getText());
				ps.setString(2, numMoviesWithPersonTF.getText());
				ps.setString(3, numMoviesWithPersonTF.getText());
				ps.setString(4, numMoviesWithPersonTF.getText());
				//cmd = "SELECT Count(Movie_Name) FROM MOVIES WHERE Director_id LIKE '"+numMoviesWithPersonTF.getText() +"' or Actor_id LIKE '"+numMoviesWithPersonTF.getText()+"' or Actress_id ='"+numMoviesWithPersonTF.getText()+"'or Supporting_id='"+ numMoviesWithPersonTF.getText()+"'";
				
				
				rs=ps.executeQuery();
				
				//rs = stmt.executeQuery(cmd);
				while(rs.next()){
					//System.out.print(rs.getString(1));
					numMoviesWithPersonTF.setText(rs.getString(1));
				}
				ps.close();
				///System.out.print("this is the result set"+rs.getString());
				
			}catch(SQLException sqle){
				System.out.print("Error with numMoviesWithPerson:\n"+sqle.toString());
				sqle.printStackTrace();
			}
		}
		if(target == movieProfitability) {
			try {
				//PreparedStatement ps=con.prepareStatement("SELECT (Earnings-Budget) AS Profit FROM Movies WHERE Movie_id=?");
				//cmd = "SELECT (Earnings-Budget) AS Profit FROM Movies WHERE Movie_id="+movieProfitabilityTF.getText();
				//ps.setString(1,movieProfitabilityTF.getText());
				//rs = stmt.executeQuery(cmd);
				//rs = ps.executeQuery();
				PreparedStatement ps=con.prepareStatement("SELECT fnMovieProfit(?);");
				ps.setString(1,movieProfitabilityTF.getText()); 
				
				rs=ps.executeQuery();
				//rs=stmt.executeQuery("SELECT fnMovieProfit("+ps+");");
				//stmt.executeUpdate("CALL spUpdatePerson("+PersonIDTF.getText() +", '"+FirstNameTF.getText()+"', '"+LastNameTF.getText()+"',"+AgeTF.getText()+",'"+CountryTF.getText()+"');");
				//rs = ps.executeQuery();
				//System.out.print(rs.getString(1));
				
				while(rs.next()) {
					movieProfitabilityTF.setText(rs.getString(1));
				}
				ps.close();
				//movieProfitabilityTF.setText(rs.toString());
			}catch(SQLException sqle){
				System.out.print("Error with movieProfitability:\n"+sqle.toString());
				sqle.printStackTrace();
			}
		}
		if(target == avgAgePerMovie) {
			try {
				//PreparedStatement ps=con.prepareStatement("SELECT AS Profit FROM Movies WHERE Movie_id=?");
				PreparedStatement ps=con.prepareStatement("SELECT Movie_id, Movie_Name, AVG(Age) AS 'AVG AGE',NOW() AS 'Taken From Database at' FROM People LEFT JOIN Movies ON Person_id=Director_id or Person_id = Actor_id or Person_id=Actress_id or Person_id =Supporting_id GROUP BY Movie_id;");
				
				//ps.setString(1,movieProfitabilityTF.getText());
				
				rs = ps.executeQuery();
				
				writeToFile(rs,"avgAge");
				ps.close();
			}catch(SQLException sqle){
				System.out.print("Error with ageAvgPerMovie:\n"+sqle.toString());
			}
		}
		if(target == NationalityInMovie) {
			try {
				PreparedStatement ps=con.prepareStatement("SELECT DISTINCT Movie_id, Movie_Name, UCASE(Country),NOW() AS 'Taken From Database at' FROM People LEFT JOIN Movies ON Person_id=Director_id or Person_id = Actor_id or Person_id=Actress_id or Person_id =Supporting_id ORDER BY Movie_id;");
				
				//ps.setString(1,movieProfitabilityTF.getText());
				
				rs = ps.executeQuery();
				
				writeToFile(rs,"MovieNationalitys");
				ps.close();
			}catch(SQLException sqle){
				System.out.print("Error with NationalityInMovie:\n"+sqle.toString());
			}
		}
	}

		/////////////////////////////////////////////////////////////////////////////////////
		//I have only added functionality of 2 of the button on the lower right of the template
		///////////////////////////////////////////////////////////////////////////////////

//		if(target == this.ListAllDepartments){
//
//			cmd = "select distinct department from details;";
//
//			try{					
//				rs= stmt.executeQuery(cmd); 	
//				writeToFile(rs);
//			}
//			catch(Exception e1){e1.printStackTrace();}
//
//		}
//
//		if(target == this.NumLectures){
//			String deptName = this.NumLecturesTF.getText();
//
//			cmd = "select department, count(*) "+  "from details " + "where department = '"  +deptName+"';";
//
//			System.out.println(cmd);
//			try{					
//				rs= stmt.executeQuery(cmd); 	
//				writeToFile(rs);
//			}
//			catch(Exception e1){e1.printStackTrace();}
//
//		} 
//
//	}
	///////////////////////////////////////////////////////////////////////////

	private void writeToFile(ResultSet rs,String tableType){
		try{
			System.out.println("In writeToFile");

			FileWriter outputFile = new FileWriter("AllDataTest.csv");
			if(tableType.equals("M")) {
				outputFile = new FileWriter("AllMovieData.csv");
			}else if(tableType.equals("P")) {
				outputFile = new FileWriter("AllPeopleData.csv");
			}else if (tableType.equals("avgAge")) {
				outputFile = new FileWriter("avgAgeData.csv");
			}else if (tableType.equals("MovieNationalitys")) {
				outputFile = new FileWriter("MovieNationalitysData.csv");
			}
			PrintWriter printWriter = new PrintWriter(outputFile);
			ResultSetMetaData rsmd = rs.getMetaData();
			int numColumns = rsmd.getColumnCount();
			
			for(int i=0;i<numColumns;i++){
				printWriter.print(rsmd.getColumnLabel(i+1)+",");
			}
			printWriter.print("\n");
			while(rs.next()){
				for(int i=0;i<numColumns;i++){
					printWriter.print(rs.getString(i+1)+",");
				}
				printWriter.print("\n");
				printWriter.flush();
			}
			printWriter.close();
		}
		catch(Exception e){e.printStackTrace();}
	}
}
