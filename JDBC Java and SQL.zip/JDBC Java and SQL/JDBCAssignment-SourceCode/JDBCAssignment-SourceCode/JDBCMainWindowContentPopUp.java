import java.awt.*;
import java.awt.event.*;
import java.io.FileWriter;
import java.io.PrintWriter;
import javax.swing.*;
import javax.swing.border.*;
import java.sql.*;


@SuppressWarnings("serial")
public class JDBCMainWindowContentPopUp extends JInternalFrame
{	
	private Container content;
	private JPanel information;
	private JLabel informationLabel;
	public JDBCMainWindowContentPopUp(String aTitle, String stringParam)
	{	
		content=getContentPane();
		content.setLayout(null);
		content.setBackground(Color.lightGray);
		
		information =new JPanel();
		informationLabel = new JLabel(stringParam);
		
		information.add(informationLabel);
		information.setSize(390,190);
		information.setLocation(5,5);
		content.add(information);
		setSize(982,645);
		setVisible(true);
	}
}
